package com.tps.challenge.features.storefeed

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tps.challenge.Constants
import com.tps.challenge.network.TPSCoroutineService
import com.tps.challenge.network.model.StoreResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import javax.inject.Inject

class StoreFeedViewModel @Inject constructor(private val service: TPSCoroutineService) :
    ViewModel() {
    private val _stores = MutableLiveData<List<StoreResponse>>()
    val stores: LiveData<List<StoreResponse>> = _stores

    private val scope = CoroutineScope(Job() + Dispatchers.Main)

    init {
        refresh()
    }

    fun refresh() {
        scope.launch {
            try {
                // Status = loading
                _stores.value =
                    service.getStoreFeed(Constants.DEFAULT_LATITUDE, Constants.DEFAULT_LONGITUDE)

                // Status = done
            } catch (e: Exception) {
                // Status = error
                Log.e("StoreFeedViewModel", "${e.message}")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        scope.cancel()
    }
}
