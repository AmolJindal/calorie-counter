package com.tps.challenge.features.storefeed

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.tps.challenge.TCApplication
import com.tps.challenge.ViewModelFactory
import com.tps.challenge.databinding.FragmentStoreFeedBinding
import javax.inject.Inject

/**
 * Displays the list of Stores with its title, description and the cover image to the user.
 */
class StoreFeedFragment : Fragment() {
    companion object {
        const val TAG = "StoreFeedFragment"
    }

    @Inject
    lateinit var viewModelFactory: ViewModelFactory<StoreFeedViewModel>

    private val viewModel: StoreFeedViewModel by lazy {
        viewModelFactory.get<StoreFeedViewModel>(
            requireActivity()
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        TCApplication.getAppComponent().inject(this)
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = FragmentStoreFeedBinding.inflate(inflater, container, false)
        // Enable if Swipe-To-Refresh functionality will be needed
        binding.swipeContainer.isEnabled = false

        initRecyclerView(binding)
        subscribeUi(binding)

        return binding.root
    }

    private fun initRecyclerView(binding: FragmentStoreFeedBinding) {
        binding.storesView.apply {
            setHasFixedSize(true)
            layoutManager = LinearLayoutManager(context)

            adapter = StoreFeedAdapter()
        }
    }

    private fun subscribeUi(binding: FragmentStoreFeedBinding) {
        viewModel.stores.observe(viewLifecycleOwner) {
            (binding.storesView.adapter as StoreFeedAdapter).submitList(it)
        }
    }
}
