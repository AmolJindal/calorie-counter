package com.play.search

import com.play.search.data.DefaultRepository
import kotlinx.coroutines.runBlocking
import org.junit.Test

class DefaultRepositoryTest {
    @Test
    fun fetched_results_are_correct() {
        val repository = DefaultRepository(FakeNetworkSource())

        runBlocking {
            val response = repository.fetch("Pizza", "Address")

            assert(response.size == 1)
            assert(response[0].name == "Best Pizza")
            assert(response[0].phoneNumber == "(123) 456 789")
            assert(response[0].address == listOf("123 XYZ St", "San Francisco", "CA"))
            assert(!response[0].isClosed)
        }
    }
}
