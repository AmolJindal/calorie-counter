package com.play.search

import com.play.search.data.yelp.YelpDataSource
import kotlinx.coroutines.runBlocking
import org.junit.Test

class YelpDataSourceTest {
    @Test
    fun model_transformation_is_correct() {
        val yelpDataSource = YelpDataSource(FakeYelpApi())

        runBlocking {
            val businesses = yelpDataSource.fetchResults("Pizza", "Address", 20, 0)

            assert(businesses.size == 1)
            assert(businesses[0].name == "Best Pizza")
            assert(businesses[0].phoneNumber == "(123) 456 789")
            assert(businesses[0].address == listOf("123 XYZ St", "San Francisco", "CA"))
            assert(!businesses[0].isClosed)
        }
    }
}
