package com.play.search

import com.play.search.data.NetworkDataSource
import com.play.search.model.Business

class FakeNetworkSource : NetworkDataSource {

    private val fakeBusiness = Business(
        "id_1",
        "Best Pizza",
        4.0,
        "fakeURL",
        "(123) 456 789",
        listOf("123 XYZ St", "San Francisco", "CA"),
        false
    )

    override suspend fun fetchResults(
        query: String,
        location: String,
        limit: Int,
        offset: Int
    ): List<Business> {
        return listOf(fakeBusiness)
    }

    override suspend fun fetchResults(
        query: String,
        latitude: Double,
        longitude: Double,
        limit: Int,
        offset: Int
    ): List<Business> {
        return listOf(fakeBusiness)
    }
}