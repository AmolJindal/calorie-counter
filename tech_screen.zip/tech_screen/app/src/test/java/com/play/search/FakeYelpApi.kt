package com.play.search

import com.play.search.data.yelp.*

class FakeYelpApi : YelpApi {

    private val fakeBusiness = YelpBusiness(
        emptyList(),
        Coordinate(0.0, 0.0),
        "(123) 456 789",
        1.0,
        "id_1",
        "",
        "fake_url",
        false,
        Location(
            "123 XYZ St",
            "San Francisco",
            "CA",
            "SF",
            "USA",
            listOf("123 XYZ St", "San Francisco", "CA"),
            "",
            ""
        ),
        "Best Pizza",
        "(123) 456 789",
        4.0,
        1000,
        "fakeURL",
        emptyList()
    )

    private val fakeResponse = YelpResponse(1, listOf(fakeBusiness), Region(Coordinate(0.0, 0.0)))

    override suspend fun fetchResults(
        query: String,
        location: String,
        limit: Int,
        offset: Int
    ): YelpResponse = fakeResponse

    override suspend fun fetchResults(
        query: String,
        latitude: Double,
        longitude: Double,
        limit: Int,
        offset: Int
    ): YelpResponse = fakeResponse
}
