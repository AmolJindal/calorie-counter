package com.play.search.data

import com.play.search.model.Business

interface Repository {
    suspend fun fetch(
        query: String,
        location: String,
        limit: Int = 20,
        offset: Int = 0
    ): List<Business>

    suspend fun fetch(
        query: String,
        latitude: Double,
        longitude: Double,
        limit: Int = 20,
        offset: Int = 0
    ): List<Business>
}
