package com.play.search.data.yelp

import com.squareup.moshi.Json

data class YelpResponse(
    val total: Int,
    val businesses: List<YelpBusiness>,
    val region: Region
)

data class YelpBusiness(
    val categories: List<BusinessCategory>,
    val coordinates: Coordinate,
    @Json(name = "display_phone") val displayPhone: String,
    val distance: Double,
    val id: String,
    val alias: String,
    @Json(name = "image_url") val imageUrl: String,
    @Json(name = "is_closed") val isClosed: Boolean,
    val location: Location,
    val name: String,
    val phone: String,
    val rating: Double,
    @Json(name = "review_count") val reviewCount: Int,
    val url: String,
    val transactions: List<String>
)

data class BusinessCategory(val alias: String, val title: String)

data class Region(val center: Coordinate)

data class Coordinate(val latitude: Double, val longitude: Double)

data class Location(
    val address1: String,
    val address2: String?,
    val address3: String?,
    val city: String,
    val country: String,
    @Json(name = "display_address") val displayAddress: List<String>,
    val state: String,
    @Json(name = "zip_code") val zipCode: String
)
