package com.play.search.data.yelp

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

object Retrofit {
    private const val YELP_BASE_URL = "https://api.yelp.com/v3/"

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    val yelpApi: YelpApi by lazy {
        Retrofit.Builder().addConverterFactory(MoshiConverterFactory.create(moshi))
            .baseUrl(YELP_BASE_URL)
            .build().create(YelpApi::class.java)
    }
}
