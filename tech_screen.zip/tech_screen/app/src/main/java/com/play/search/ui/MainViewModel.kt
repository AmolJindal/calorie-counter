package com.play.search.ui

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.play.search.model.Business
import com.play.search.data.Repository
import kotlinx.coroutines.launch

class MainViewModel(private val repository: Repository) : ViewModel() {

    private val _businesses = MutableLiveData<List<Business>>()
    val businesses: LiveData<List<Business>> = _businesses

    var location: String = ""
    var latitude: Double = 0.0
    var longitude: Double = 0.0
    var useCoordinates = false

    fun search(queries: List<String>) {
        viewModelScope.launch {
            try {
                val combinedList = mutableListOf<Business>()

                // Let UI know that operation has started

                queries.forEach { query ->
                    val response = if (useCoordinates)
                        repository.fetch(query, latitude, longitude)
                    else
                        repository.fetch(query, location)

                    combinedList.addAll(response)
                }

                // Let UI know that operation has ended

                _businesses.value = combinedList
            } catch (e: Exception) {
                // Let UI know that operation has failed
                Log.e("MainViewModel", "${e.message}")
            }
        }
    }
}
