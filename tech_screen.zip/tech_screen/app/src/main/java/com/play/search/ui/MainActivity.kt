package com.play.search.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.play.search.CustomFactory
import com.play.search.SearchApp
import com.play.search.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this, CustomFactory {
            MainViewModel(SearchApp.repository)
        })[MainViewModel::class.java]

        setupRecyclerView()
        subscribeUi()

        // These operations can happen as a result of some user action
        viewModel.location = "111 Sutter Street San Francisco, CA"
        viewModel.search(listOf("Pizza", "Beer"))
    }

    private fun subscribeUi() {
        viewModel.businesses.observe(this) {
            (binding.list.adapter as BusinessAdapter).submitList(it)
        }
    }

    private fun setupRecyclerView() {
        binding.list.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = BusinessAdapter()
        }
    }
}
