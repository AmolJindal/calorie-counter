package com.play.search

import android.app.Application
import com.play.search.data.DefaultRepository
import com.play.search.data.yelp.Retrofit
import com.play.search.data.yelp.YelpDataSource
import kotlinx.coroutines.Dispatchers

class SearchApp : Application() {
    companion object {
        val repository by lazy {
            val yelpDataSource = YelpDataSource(Retrofit.yelpApi, Dispatchers.IO)
            DefaultRepository(yelpDataSource, Dispatchers.IO)
        }
    }
}
