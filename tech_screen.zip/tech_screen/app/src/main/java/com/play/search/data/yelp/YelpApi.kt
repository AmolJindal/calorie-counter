package com.play.search.data.yelp

import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

interface YelpApi {

    // API key can be removed from here and can be fetched from local.properties file

    @GET("businesses/search")
    @Headers("Authorization: Bearer 2ROaa2Rh9qu3WVTCms8FoVE4mSfHQHC7QJua95-kKT-PqzIlLSrs4tmHVdtdFw_66-JNfRiJmbCByHTvFNy5dQq-tpfS4FrPpupIzKlgELR3br-r5trpeFhrCRgwWnYx")
    suspend fun fetchResults(
        @Query("term") query: String,
        @Query("location") location: String,
        @Query("limit") limit: Int,
        @Query("offset") offset: Int
    ): YelpResponse

    @GET("businesses/search")
    @Headers("Authorization: Bearer 2ROaa2Rh9qu3WVTCms8FoVE4mSfHQHC7QJua95-kKT-PqzIlLSrs4tmHVdtdFw_66-JNfRiJmbCByHTvFNy5dQq-tpfS4FrPpupIzKlgELR3br-r5trpeFhrCRgwWnYx")
    suspend fun fetchResults(
        @Query("term") query: String,
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("limit") limit: Int,
        @Query("offset") offset: Int
    ): YelpResponse
}
