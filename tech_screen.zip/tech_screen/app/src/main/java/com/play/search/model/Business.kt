package com.play.search.model

// Model used by UI
data class Business(
    val id: String,
    val name: String,
    val rating: Double,
    val thumbUrl: String,
    val phoneNumber: String,
    val address: List<String>,
    val isClosed: Boolean
)
