package com.play.search.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.play.search.R
import com.play.search.model.Business
import com.play.search.databinding.ViewholderBusinessBinding

class BusinessViewHolder private constructor(private val binding: ViewholderBusinessBinding) :
    RecyclerView.ViewHolder(binding.root) {

    fun bind(business: Business) {
        binding.apply {
            name.text = business.name
            rating.text = business.rating.toString()
            address.text = business.address.toString()
            phone.text = business.phoneNumber
            isOpen.text =
                itemView.context.getString(if (business.isClosed) R.string.closed else R.string.open)

            thumb.load(business.thumbUrl)
        }
    }

    companion object {
        fun from(parent: ViewGroup): BusinessViewHolder {
            val binding = ViewholderBusinessBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )

            return BusinessViewHolder(binding)
        }
    }
}