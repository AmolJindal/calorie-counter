package com.play.search.data

import com.play.search.model.Business
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DefaultRepository(
    private val networkDataSource: NetworkDataSource,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO
) : Repository {

    override suspend fun fetch(
        query: String,
        location: String,
        limit: Int,
        offset: Int
    ): List<Business> = withContext(dispatcher) {
        networkDataSource.fetchResults(
            query,
            location,
            limit,
            offset
        )
    }

    override suspend fun fetch(
        query: String,
        latitude: Double,
        longitude: Double,
        limit: Int,
        offset: Int
    ): List<Business> = withContext(dispatcher) {
        networkDataSource.fetchResults(
            query,
            latitude,
            longitude,
            limit,
            offset
        )
    }
}
