package com.play.search.data.yelp

import com.play.search.model.Business
import com.play.search.data.NetworkDataSource
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class YelpDataSource(
    private val yelpApi: YelpApi,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO
) :
    NetworkDataSource {

    private fun transformYelpResponse(response: YelpResponse): List<Business> {
        return response.businesses.map {
            Business(
                it.id,
                it.name,
                it.rating,
                it.imageUrl,
                it.displayPhone,
                it.location.displayAddress,
                it.isClosed
            )
        }
    }

    override suspend fun fetchResults(
        query: String,
        location: String,
        limit: Int,
        offset: Int
    ): List<Business> = withContext(dispatcher) {
        transformYelpResponse(yelpApi.fetchResults(query, location, limit, offset))
    }

    override suspend fun fetchResults(
        query: String,
        latitude: Double,
        longitude: Double,
        limit: Int,
        offset: Int
    ): List<Business> = withContext(dispatcher) {
        transformYelpResponse(yelpApi.fetchResults(query, latitude, longitude, limit, offset))
    }
}
