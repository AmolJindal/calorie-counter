package com.play.search.data

import com.play.search.model.Business

interface NetworkDataSource {
    suspend fun fetchResults(
        query: String,
        location: String,
        limit: Int,
        offset: Int
    ): List<Business>

    suspend fun fetchResults(
        query: String,
        latitude: Double,
        longitude: Double,
        limit: Int,
        offset: Int
    ): List<Business>
}
